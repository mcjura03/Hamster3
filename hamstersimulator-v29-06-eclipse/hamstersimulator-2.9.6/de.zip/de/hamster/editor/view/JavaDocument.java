package de.hamster.editor.view;

import de.hamster.compiler.model.HamsterLexer;
import de.hamster.compiler.model.JavaToken;
import de.hamster.workbench.Workbench;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.util.Iterator;
import java.util.LinkedList;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyleConstants;
import javax.swing.text.TabSet;
import javax.swing.text.TabStop;

/**
 * @author $Author: djasper $
 * @version $Revision: 1.1 $
 */
public class JavaDocument extends HamsterDocument implements DocumentListener {
	int lineHeight;

	public JavaDocument(boolean printing) {
		scanner = new HamsterLexer();
		addDocumentListener(this);
		initStyles(printing, Workbench.getWorkbench().getFontSize());
	}

	public void initStyles(boolean printing, int fontSize) {
		addStyle("plain", getStyle("default"));
		if (!printing) {
			StyleConstants.setFontFamily(getStyle("plain"), "Monospaced");
			StyleConstants.setFontSize(getStyle("plain"), fontSize);
			StyleConstants.setForeground(getStyle("plain"), Color.WHITE); // jrahn: Standard-Textfarbe auf weiß gesetzt

			/* alt
			TabStop[] ts = new TabStop[10];
			for (int i = 0; i < ts.length; i++)
				ts[i] = new TabStop((i + 1) * 28);
			StyleConstants.setTabSet(getStyle("plain"), new TabSet(ts));
			*/

			// dibo 210110 neu
			TabSet set = calcTabs(4, this.getFont(this.getStyle("plain")));
			StyleConstants.setTabSet(this.getStyle("plain"), set);

			setParagraphAttributes(0, getLength(), getStyle("plain"), true);

			addStyle("keyword", getStyle("plain"));
			StyleConstants.setBold(getStyle("keyword"), true);
			StyleConstants.setForeground(getStyle("keyword"),
					new Color(128, 169, 98)); // jrahn: Keyword-Farbe auf HEX #80A962 umgestellt

			addStyle("method", getStyle("plain")); // jrahn: Methodenstil ergänzt
			StyleConstants.setBold(getStyle("method"), true); // jrahn: Methoden fett darstellen

			addStyle("comment", getStyle("plain"));
			StyleConstants.setForeground(getStyle("comment"), new Color(200,
					200, 200));

			addStyle("literal", getStyle("plain"));
			StyleConstants.setForeground(getStyle("literal"), Color.BLUE);
		} else {
			StyleConstants.setFontFamily(getStyle("plain"), "Courier New");
			StyleConstants.setFontSize(getStyle("plain"), 10);
			TabStop[] ts = new TabStop[10];
			for (int i = 0; i < ts.length; i++)
				ts[i] = new TabStop((i + 1) * 28);
			StyleConstants.setTabSet(getStyle("plain"), new TabSet(ts));
			setParagraphAttributes(0, getLength(), getStyle("plain"), true);

			addStyle("keyword", getStyle("plain"));
			StyleConstants.setBold(getStyle("keyword"), true);
			StyleConstants.setForeground(getStyle("keyword"),
					new Color(128, 169, 98)); // jrahn: Keyword-Farbe auch im Druckmodus angepasst

			addStyle("method", getStyle("plain")); // jrahn: Methodenstil ergänzt
			StyleConstants.setBold(getStyle("method"), true); // jrahn: Methoden auch im Druckmodus fett

			addStyle("comment", getStyle("plain"));
			StyleConstants.setForeground(getStyle("comment"), new Color(20,
					20, 20));

			addStyle("literal", getStyle("plain"));
			StyleConstants.setForeground(getStyle("literal"), new Color(20,
					20, 20));
		}

		// dibo 210110
		Font f = this.getFont(this.getStyle("plain"));
		FontMetrics fm = new JPanel().getFontMetrics(f);
		lineHeight = fm.getHeight();

		tokens = new LinkedList();
	}

	// dibo 230309 und 210110
	public void changeFontSize(int size) {
		// neu
		this.removeStyle("plain");
		this.removeStyle("keyword");
		this.removeStyle("method"); // jrahn: Methodenstil beim Neuaufbau entfernen
		this.removeStyle("comment");
		this.removeStyle("literal");

		initStyles(false, size);

		/* alt
		StyleConstants.setFontSize(getStyle("plain"), size);
		TabSet set = calcTabs(4, this.getFont(this.getStyle("plain")));
		StyleConstants.setTabSet(this.getStyle("plain"), set);
		*/

		SwingUtilities
				.invokeLater(new RunRehighlight(0, this.getLength(), this));
	}

	JavaToken first() {
		return (JavaToken) tokens.getFirst();
	}

	int copyAllBefore(int pos, LinkedList newTokens) {
		int start = 0;
		while (!tokens.isEmpty()
				&& first().getStart() + first().getText().length() < pos) {
			start = first().getStart() + first().getText().length();
			// System.out.println("copy-before: " + first());
			newTokens.addLast(tokens.removeFirst());
		}
		return start;
	}

	public JavaToken getTokenAt(int pos) {
		int start = 0;
		for (Iterator iter = tokens.iterator(); iter.hasNext();) {
			JavaToken token = (JavaToken) iter.next();
			if (token.getStart() >= pos)
				return token;
		}
		return null;
	}

	boolean exists(JavaToken t, int offset) {
		while (!tokens.isEmpty()) {
			if (first().getStart() + offset == t.getStart())
				return true;
			else if (first().getStart() + offset < t.getStart())
				tokens.removeFirst();
			else
				return false;
		}
		return false;
	}

	void copyAllAfter(LinkedList newTokens, int offset) {
		while (!tokens.isEmpty()) {
			JavaToken t = first();
			t.setStart(t.getStart() + offset);
			// System.out.println("copy-after: " + t);
			newTokens.addLast(tokens.removeFirst());
		}
	}

	void setAttributes(JavaToken t) {
		if (t.getType() == HamsterLexer.COMMENT) {
			setCharacterAttributes(t.getStart(), t.getText().length() + 1, // dibo 230309
					getStyle("comment"), true);
		} else if (t.getType() == HamsterLexer.KEYWORD) {
			setCharacterAttributes(t.getStart(), t.getText().length(),
					getStyle("keyword"), true);
		} else if (t.getType() == HamsterLexer.METHOD) { // jrahn: Methodenstil ergänzt
			setCharacterAttributes(t.getStart(), t.getText().length(),
					getStyle("method"), true); // jrahn: Methoden fett darstellen
		} else if (t.getType() == HamsterLexer.LITERAL) {
			setCharacterAttributes(t.getStart(), t.getText().length() + 1, // dibo 230309
					getStyle("literal"), true);
		} else {
			setCharacterAttributes(t.getStart(), t.getText().length() + 1, // dibo 230309
					getStyle("plain"), true);
		}
	}

	public boolean isHighlighting() {
		return highlighting;
	}

	public void rehighlight(int pos, int len) {
		highlighting = true;
		long s = System.currentTimeMillis();
		LinkedList newTokens = new LinkedList();
		int start = copyAllBefore(pos, newTokens);

		try {
			scanner.init(0, start, getText(start, getLength() - start));
		} catch (BadLocationException e1) {
			// TODO should not happen
		}
		while (scanner.ready()) {
			JavaToken t = scanner.nextToken();
			if (t == null)
				break;
			if (t.getStart() > pos && exists(t, len)) {
				copyAllAfter(newTokens, len);
				break;
			}
			setAttributes(t);
			newTokens.addLast(t);
		}
		tokens = newTokens;

		highlighting = false;
	}

	public void changedUpdate(DocumentEvent e) {
	}

	public void insertUpdate(DocumentEvent e) {
		SwingUtilities.invokeLater(new RunRehighlight(e.getOffset(), e
				.getLength(), this));
	}

	public void removeUpdate(DocumentEvent e) {
		SwingUtilities.invokeLater(new RunRehighlight(e.getOffset(), -e
				.getLength(), this));
	}
}